﻿using BarChartToPdf.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using DinkToPdf;
using DinkToPdf.Contracts;
using System.IO;
using System.Threading.Tasks;

namespace BarChartToPdf.Controllers
{
    public class HomeController : Controller
    {
        

        private readonly PdfConverterService _pdfConverterService;
      public IActionResult Index()
        {
           GeneratePdf();
            return View();
        }

      

        public async Task<IActionResult> GeneratePdf()
        {
            // Generate or retrieve your HTML content with the bar chart.
            string htmlContent = "<html><body><canvas id='bar-chart'></canvas></body></html>";

            // Convert HTML to PDF
            var pdfBytes = await _pdfConverterService.ConvertHtmlToPdfAsync(htmlContent);

            // Return the PDF as a file download
            return File(pdfBytes, "application/pdf", "chart.pdf");
        }

       

       

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}



public class PdfConverterService
{
    private readonly IConverter _converter;

    public PdfConverterService(IConverter converter)
    {
        _converter = converter;
    }

    public async Task<byte[]> ConvertHtmlToPdfAsync(string htmlContent)
    {
        var doc = new HtmlToPdfDocument()
        {
            Objects = {
                new ObjectSettings
                {
                    PagesCount = true,
                    HtmlContent = htmlContent,
                    WebSettings = { DefaultEncoding = "utf-8" },
                }
            }
        };

        return  _converter.Convert(doc);
    }
}